"""Run and inspect annotation-free AutoNR on phosphatase ProtT5.

Start here when returning to this file:
* ``preflight`` (the default) checks source and input without fitting.
* ``run --run-id NAME`` reserves a new attempt and launches a monitored child.
* ``validate --run-id NAME`` reopens numeric outputs and checks their provenance.
* ``figures --run-id NAME`` plots the saved cluster-size table without fitting.

AutoNR chooses several partitions, one per learned subspace. Label columns are
local to a run: column 0 in two runs need not describe the same grouping. Keep
every column. A label of -1 is an outlier in that column only; a one-cluster
space is a noise space, not a list of rejected proteins.

The estimator, MDL, initialisation and metrics are library calls. This file owns
input checks, process management and evidence on disk. Settings follow the
reviewed ClustPy 0.0.2 source and Leiber et al., SDM 2022 (supplied PDF, supplement
sections 5-6). See tmp/autonr_standalone_todo.md for experiment decisions.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time
import traceback

import numpy as np
import pandas as pd
import psutil
from threadpoolctl import threadpool_info

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO))
from src.data import DATASETS, deduplicate, load_dataset

ROOT = REPO / 'results/autonr'
# These hashes identify the installed release reviewed on 23 September 2026.
# A matching version string alone does not identify code in a reference clone.
SOURCES = {
    'alternative/autonr.py': '21e021871ad0d902494bbecd5952001459e7407530291163039666b7b9c7ec79',
    'alternative/nrkmeans.py': 'f97143dba2cf6ca25a25a554567192c97a668176f1ae8e552531bea86763701e',
    'utils/_information_theory.py': '4267c915fe4887bd1b300ab1d56e519d383f3d41635346b1bfb98a0ff06ab6b3',
}
# DERIVED: the release accepts orthogonality errors of 1e-6. This is a numerical
# validation tolerance, not a threshold for deciding whether a result is good.
ORTHOGONAL_ATOL = 1e-6


def digest(path):
    """Stream file hashes so evidence collection does not load large files twice."""
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    """Write once: an old result must never silently become a new attempt.

    Exclusive creation follows the helper in src/algo/subkmeans/
    subkmeans_standalone.py; no other standalone is imported.
    """
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def verify_source():
    """Check the actual import path as well as the reviewed implementation bytes."""
    import clustpy
    from clustpy.alternative import AutoNR
    package = Path(clustpy.__file__).resolve().parent
    if importlib.metadata.version('clustpy') != '0.0.2':
        raise ValueError('Review the changed ClustPy version before fitting')
    for relative, expected in SOURCES.items():
        if digest(package / relative) != expected:
            raise ValueError(f'ClustPy source mismatch: {relative}')
    if Path(inspect.getfile(AutoNR)).resolve() != package / 'alternative/autonr.py':
        raise ValueError('AutoNR import is not the checked implementation')
    return AutoNR


def constructor(seed):
    """Declare all native options; do not add an outer best-of-seeds selector.

    DERIVED: defaults in the pinned AutoNR constructor, except the CHOSEN seed
    and debug=True for a search log. The paper supplement section 6 also uses
    15 internal repetitions. None bounds resolve to input width and row count.
    Native NrKmeans calls use max_iter=300 and n_init=1; AutoNR itself manages
    its repeated candidates and warm starts. We leave that search untouched.
    """
    return dict(nrkmeans_repetitions=15, outliers=True, max_subspaces=None,
                max_n_clusters=None, mdl_for_noisespace=True, max_distance=None,
                precision=None, similarity_threshold=1e-5, random_state=seed,
                debug=True)


def canonical_input(ids, X):
    """Sort IDs and coordinates together; reject ambiguous or malformed rows.

    Adapted from src/algo/subkmeans/subkmeans_standalone.py::canonical_input.
    No annotations are accepted by the fit function below.
    """
    ids, X = np.asarray(ids), np.asarray(X)
    if (ids.ndim != 1 or ids.dtype.kind not in 'US'
            or len(np.unique(ids)) != len(ids) or np.any(ids == '')):
        raise ValueError('Protein IDs must be unique nonempty strings')
    if (X.ndim != 2 or X.shape[0] != len(ids) or min(X.shape) < 2
            or X.dtype.kind not in 'fi' or not np.isfinite(X).all()):
        raise ValueError('Coordinates must be finite, numeric and aligned with IDs')
    order = np.argsort(ids, kind='stable')
    return ids[order], np.ascontiguousarray(X[order], dtype=np.float64)


def pca90(X):
    """Fit the paper's 90% variance rule on the full, canonical float64 input.

    QUOTED: paper p. 7 uses PCA retaining 90% when d > 50. No whitening or
    feature scaling is added. Save the basis because a PCA run has different
    input geometry from a raw run, even though it contains the same proteins.
    """
    from sklearn.decomposition import PCA
    pca = PCA(n_components=0.90, svd_solver='full', whiten=False).fit(X)
    return np.ascontiguousarray(pca.transform(X)), dict(
        pca_components=pca.components_, pca_mean=pca.mean_,
        pca_explained_variance_ratio=pca.explained_variance_ratio_,
        pca_explained_variance=pca.explained_variance_,
        pca_singular_values=pca.singular_values_,
        pca_fit_n=np.array(X.shape[0]))


def prepare(records, geometry='raw', transform_out=None):
    """Align rows and fit PCA on all records before any sensitivity subset.

    Raw remains the default. PCA is a separately requested experiment, not a
    remedy silently applied to a slow raw run. transform_out optionally receives
    the fitted numeric basis for persistence; annotations never enter PCA.
    """
    ds = load_dataset('phosphatase')
    stored_dtype = str(ds.X.dtype)
    ids, X = canonical_input(ds.ids, ds.X)
    if geometry == 'pca90':
        X, basis = pca90(X)
        if transform_out is not None:
            transform_out.update(basis)
    elif geometry != 'raw':
        raise ValueError('Unknown input geometry')
    if records == 'dedup':
        mask = np.isin(ids, deduplicate(ds).ids)
        ids, X = ids[mask], np.ascontiguousarray(X[mask])
    return ids, X, stored_dtype


def input_signature(ids, X):
    return dict(n=len(ids), d=X.shape[1], fit_dtype=str(X.dtype),
                subset_hash=hashlib.sha256('\n'.join(ids).encode()).hexdigest(),
                coordinates_sha256=hashlib.sha256(X.tobytes()).hexdigest())


def coding_quantities(X):
    """Ask the pinned library for its coding constants, without replacing them.

    Constant features are skipped by its precision rule; entirely constant data
    have no valid precision. Refuse those data rather than invent an epsilon.
    The library recomputes these values during fit; this check records what its
    None defaults mean and catches invalid input before starting a search.
    """
    from clustpy.alternative.autonr import _check_input_parameters
    bounds = _check_input_parameters(X, 15, None, None, None, None)
    if not np.isfinite(bounds[2:]).all() or min(bounds[2:]) <= 0:
        raise ValueError('Native distance scale and precision must be finite and positive')
    return dict(max_subspaces=int(bounds[0]), max_n_clusters=int(bounds[1]),
                max_distance=float(bounds[2]), precision=float(bounds[3]))


def provenance(ids, X, stored_dtype, records, seed, geometry='raw'):
    """Record only relevant environment information, never dump environment secrets."""
    verify_source()
    git_sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                      text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO,
                                    text=True).strip()
    return dict(input=input_signature(ids, X), records=records, geometry=geometry,
                stored_dtype=stored_dtype,
                transform='none' if geometry == 'raw' else
                    dict(method='PCA', variance_target=0.90, solver='full', whiten=False,
                         fit_population='all canonical phosphatase records'),
                constructor=constructor(seed),
                resolved=coding_quantities(X), git_sha=git_sha + ('-dirty' if dirty else ''),
                runner_sha256=digest(__file__), data_helper_sha256=digest(REPO / 'src/data.py'),
                input_files={str(p.relative_to(REPO)): digest(p)
                             for p in DATASETS['phosphatase'] if p is not None},
                library_sources=SOURCES, python=sys.version, platform=platform.platform(),
                versions={name: importlib.metadata.version(name) for name in
                          ('clustpy', 'numpy', 'scipy', 'scikit-learn', 'pandas', 'psutil')},
                threadpools=threadpool_info(), thread_environment={k: os.environ.get(k) for k in
                    ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS')},
                inner_defaults=dict(max_iter=300, n_init=1, cost_type='default',
                                    threshold_negative_eigenvalue=-1e-7),
                monitoring='psutil sampled process-tree RSS/CPU and available system RAM; no hard cap')


def fit_arrays(ids, X, seed):
    """One fresh AutoNR fit, preserving all learned spaces and native diagnostics."""
    AutoNR = verify_source()
    model = AutoNR(**constructor(seed)).fit(X)
    nr = model.nrkmeans_
    arrays = dict(protein_id=ids, label=model.labels_, V=nr.V,
                  m=np.asarray(nr.m), n_clusters=np.asarray(model.n_clusters_))
    for j in range(len(nr.m)):
        # Ragged lists become separate numeric keys. Object arrays need pickle,
        # which is unnecessary for these results and unsafe when reopening them.
        arrays[f'P_{j}'] = np.asarray(nr.P[j])
        arrays[f'centres_{j}'] = nr.cluster_centers[j]
        arrays[f'scatter_{j}'] = nr.scatter_matrices_[j]
        np.testing.assert_allclose(X @ nr.V[:, nr.P[j]], nr.transform_subspace(X, j),
                                   rtol=0, atol=ORTHOGONAL_ATOL)
    total, global_cost, subspace_costs = nr.calculate_mdl_costs(X)
    if not np.isfinite([total, global_cost, *subspace_costs]).all():
        raise ValueError('Nonfinite final MDL')
    np.testing.assert_allclose(total, model.mdl_costs_, rtol=1e-10, atol=1e-6)
    history = [dict(index=i, costs=float(h.costs), full_space=bool(h.full_space_execution),
                    operation=h.originates_from_operation) for i, h in enumerate(model.all_mdl_costs_)]
    # full_space_execution means evaluated on the full input, not "accepted".
    # Candidate costs need not be monotone and may use different subspace inputs.
    info = dict(mdl=float(total), global_mdl=float(global_cost),
                subspace_mdl=[float(c) for c in subspace_costs], history=history,
                outer_termination='unknown: release does not expose a stop reason',
                inner_termination='unknown: release does not expose iterations or convergence')
    validate_arrays(arrays, len(ids), X.shape[1])
    return arrays, info


def validate_arrays(a, n, d):
    """Check the saved mathematical shape without imposing a desired structure."""
    ids, labels, V, m, counts = (a[k] for k in ('protein_id', 'label', 'V', 'm', 'n_clusters'))
    if ids.shape != (n,) or ids.dtype.kind not in 'US' or len(np.unique(ids)) != n:
        raise ValueError('Invalid saved protein IDs')
    if not np.array_equal(ids, np.sort(ids)):
        raise ValueError('Saved IDs are not canonical')
    if m.ndim != 1 or m.dtype.kind not in 'iu' or len(m) == 0 or np.any(m < 1):
        raise ValueError('Invalid subspace dimensions')
    s = len(m)
    if counts.shape != (s,) or counts.dtype.kind not in 'iu' or np.any(counts < 1):
        raise ValueError('Invalid cluster counts')
    if labels.shape != (n, s) or labels.dtype.kind not in 'iu':
        raise ValueError('Labels must retain one integer column per subspace')
    if V.shape != (d, d) or not np.isfinite(V).all():
        raise ValueError('Invalid rotation')
    np.testing.assert_allclose(V.T @ V, np.eye(d), rtol=0, atol=ORTHOGONAL_ATOL)
    projections = []
    for j, (width, k) in enumerate(zip(m, counts)):
        P, centres, scatter = (a[f'{key}_{j}'] for key in ('P', 'centres', 'scatter'))
        if P.shape != (width,) or P.dtype.kind not in 'iu':
            raise ValueError('Projection and dimension disagree')
        projections.extend(P.tolist())
        if (centres.shape != (k, d) or scatter.shape != (d, d)
                or not np.isfinite(centres).all() or not np.isfinite(scatter).all()):
            raise ValueError('Invalid centres/scatter')
        column = labels[:, j]
        if np.any(column < -1) or not np.array_equal(np.unique(column[column >= 0]), np.arange(k)):
            raise ValueError('Labels and realised cluster count disagree')
    if sorted(projections) != list(range(d)) or int(sum(m)) != d:
        raise ValueError('Projections must allocate each coordinate exactly once')
    if any(v.dtype.hasobject for v in a.values()):
        raise ValueError('Object arrays are not allowed')


def save_tables(path, a, info, configuration_id):
    """Keep per-space denominators explicit; -1 is never an ordinary cluster."""
    spaces, clusters = [], []
    for j, (width, k) in enumerate(zip(a['m'], a['n_clusters'])):
        labels = a['label'][:, j]
        spaces.append(dict(configuration_id=configuration_id, subspace=j, dimensions=int(width),
                           n_clusters=int(k), noise_space=bool(k == 1), n=len(labels),
                           n_outliers=int(np.sum(labels == -1)), mdl=info['subspace_mdl'][j]))
        for label, count in zip(*np.unique(labels, return_counts=True)):
            clusters.append(dict(configuration_id=configuration_id, subspace=j,
                                 label=int(label), is_outlier=bool(label == -1), n=int(count)))
    pd.DataFrame(spaces).to_csv(path / 'subspaces.csv', index=False)
    pd.DataFrame(clusters).to_csv(path / 'clusters.csv', index=False)
    pd.DataFrame(info['history']).to_csv(path / 'search.csv', index=False)


def validate_saved(path, require_success=True):
    """Reopen outputs without pickle and bind them to the exact input and manifest."""
    config = json.loads((path / 'configuration.json').read_text())
    result = json.loads((path / 'result.json').read_text())
    if digest(path / 'model.npz') != result['archive_sha256']:
        raise ValueError('Saved archive hash mismatch')
    if digest(path / 'configuration.json') != result['configuration_id']:
        raise ValueError('Configuration hash mismatch')
    with np.load(path / 'model.npz', allow_pickle=False) as archive:
        a = {k: archive[k] for k in archive.files}
    sig = config['input']
    validate_arrays(a, sig['n'], sig['d'])
    basis = {}
    ids, X, _ = prepare(config['records'], config.get('geometry', 'raw'), basis)
    if input_signature(ids, X) != sig or not np.array_equal(ids, a['protein_id']):
        raise ValueError('Saved IDs/coordinates differ from current input')
    for name, expected in basis.items():
        np.testing.assert_array_equal(a[name], expected)
    for name, expected in result['table_hashes'].items():
        if digest(path / name) != expected:
            raise ValueError(f'Table hash mismatch: {name}')
    if require_success:
        success = json.loads((path / 'SUCCESS.json').read_text())
        if success['result_sha256'] != digest(path / 'result.json'):
            raise ValueError('Success marker does not match result')
    return a, result


def worker(path):
    """A child process owns the fit; all failures leave their attempt on disk."""
    try:
        config = json.loads((path / 'configuration.json').read_text())
        if config['runner_sha256'] != digest(__file__) or config['data_helper_sha256'] != digest(REPO / 'src/data.py'):
            raise ValueError('Code changed after preflight')
        basis = {}
        ids, X, _ = prepare(config['records'], config.get('geometry', 'raw'), basis)
        if input_signature(ids, X) != config['input']:
            raise ValueError('Input changed after preflight')
        started = time.monotonic()
        arrays, info = fit_arrays(ids, X, config['constructor']['random_state'])
        info['fit_seconds'] = time.monotonic() - started
        arrays.update(basis)
        if basis:
            info['pca_retained_variance'] = float(np.sum(basis['pca_explained_variance_ratio']))
        np.savez_compressed(path / 'model.npz', **arrays)
        info['archive_sha256'] = digest(path / 'model.npz')
        info['configuration_id'] = digest(path / 'configuration.json')
        save_tables(path, arrays, info, info['configuration_id'])
        pd.DataFrame([dict(configuration_id=info['configuration_id'], **config['input'],
                           seed=config['constructor']['random_state'], mdl=info['mdl'],
                           fit_seconds=info['fit_seconds'], subspaces=len(arrays['m']),
                           git_sha=config['git_sha'], outer_termination=info['outer_termination'],
                           inner_termination=info['inner_termination'])]).to_csv(path / 'run.csv', index=False)
        info['table_hashes'] = {name: digest(path / name) for name in
                                ('subspaces.csv', 'clusters.csv', 'search.csv', 'run.csv')}
        write_json(path / 'result.json', info)
        validate_saved(path, require_success=False)
    except BaseException:
        (path / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise


def stop_tree(pid):
    """Cancel only the child process tree owned by this attempt, never by name."""
    try:
        parent = psutil.Process(pid)
        processes = parent.children(recursive=True) + [parent]
    except psutil.NoSuchProcess:
        return
    for process in reversed(processes):
        try:
            process.terminate()
        except psutil.NoSuchProcess:
            pass
    # CHOSEN cleanup grace of five seconds, not a scientific runtime limit.
    _, alive = psutil.wait_procs(processes, timeout=5)
    for process in alive:
        try:
            process.kill()
        except psutil.NoSuchProcess:
            pass


def run(path, records, seed, geometry='raw'):
    """Reserve first, record configuration, then monitor an uncapped child fit.

    Ctrl+C or a file named CANCEL in this attempt requests cancellation. Nothing
    here kills a fit for elapsed time or measured RAM. RSS is sampled resident
    memory, not a promise about peak committed memory or physical capacity.
    """
    path.mkdir(parents=True, exist_ok=False)
    ids, X, stored = prepare(records, geometry)
    write_json(path / 'configuration.json', provenance(ids, X, stored, records, seed, geometry))
    started = time.monotonic()
    cancelled = False
    with (path / 'stdout.log').open('x') as stdout, (path / 'stderr.log').open('x') as stderr:
        process = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()),
                                    '_worker', '--attempt', str(path.resolve())],
                                   stdout=stdout, stderr=stderr, cwd=REPO)
        write_json(path / 'process.json', dict(pid=process.pid, started_unix=time.time()))
        try:
            with (path / 'resources.csv').open('x', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=['elapsed_seconds', 'rss_bytes',
                    'cpu_seconds', 'available_system_bytes'])
                writer.writeheader()
                while process.poll() is None:
                    if (path / 'CANCEL').exists():
                        cancelled = True
                        stop_tree(process.pid)
                        break
                    rss, cpu = 0, 0.0
                    try:
                        parent = psutil.Process(process.pid)
                        for p in [parent] + parent.children(recursive=True):
                            try:
                                rss += p.memory_info().rss
                                times = p.cpu_times()
                                cpu += times.user + times.system
                            except psutil.NoSuchProcess:
                                pass
                    except psutil.NoSuchProcess:
                        pass
                    writer.writerow(dict(elapsed_seconds=time.monotonic() - started,
                                         rss_bytes=rss, cpu_seconds=cpu,
                                         available_system_bytes=psutil.virtual_memory().available))
                    stream.flush()
                    time.sleep(1)  # CHOSEN observation interval, not a runtime cap.
        except BaseException:
            cancelled = True
            stop_tree(process.pid)
            raise
        finally:
            code = process.wait()
            write_json(path / 'process_outcome.json', dict(returncode=code, cancelled=cancelled,
                       elapsed_seconds=time.monotonic() - started))
    if cancelled or code != 0:
        raise RuntimeError(f'Attempt did not complete: {path}; inspect stderr.log and failure.txt')
    validate_saved(path, require_success=False)
    write_json(path / 'SUCCESS.json', dict(result_sha256=digest(path / 'result.json')))
    print(f'Validated result: {path}')


def figures(path):
    """A standard size plot from checked tables, including explicit outlier bars."""
    import matplotlib.pyplot as plt
    validate_saved(path)
    table = pd.read_csv(path / 'clusters.csv')
    target = path / 'figures'
    target.mkdir(exist_ok=False)
    for subspace, rows in table.groupby('subspace'):
        fig, ax = plt.subplots(figsize=(8, 4))  # CHOSEN display size only.
        ax.bar(rows['label'].astype(str), rows['n'])
        ax.set(xlabel='Cluster label (-1 = outlier in this subspace)', ylabel='Proteins',
               title=f'AutoNR subspace {subspace}: all retained records')
        fig.tight_layout()
        fig.savefig(target / f'cluster_sizes_{subspace}.png', dpi=150)
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', nargs='?', default='preflight',
                        choices=['preflight', 'run', 'validate', 'figures', '_worker'])
    parser.add_argument('--run-id')
    parser.add_argument('--records', choices=['full', 'dedup'], default='full')
    parser.add_argument('--geometry', choices=['raw', 'pca90'], default='raw',
                        help='PCA90 is a separate input experiment; raw is unchanged')
    parser.add_argument('--seed', type=int, default=0, help='CHOSEN reproducibility seed; no quality selection')
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--attempt', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.mode == '_worker':
        worker(args.attempt)
        return
    if args.mode == 'preflight':
        ids, X, stored = prepare(args.records, args.geometry)
        print(json.dumps(provenance(ids, X, stored, args.records, args.seed, args.geometry), indent=2))
        return
    if not args.run_id or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', args.run_id):
        parser.error('--run-id must contain only letters, digits, underscores or hyphens')
    path = args.root / 'attempts' / args.run_id
    if args.mode == 'run':
        run(path, args.records, args.seed, args.geometry)
    elif args.mode == 'validate':
        validate_saved(path)
        print(f'Validated: {path}')
    else:
        figures(path)


if __name__ == '__main__':
    main()
