"""Loading and pre-clustering profiling for a ProtT5 embedding set.

Four jobs:

1. Load the embeddings and the annotation table, and assert they line up.
2. Scale facts: L2 norms, and whether magnitude tracks sequence length.
3. Duplicate facts: how many proteins share a vector, which ones, and whether they also share a
   sequence. The last part needs a FASTA and is skipped, not faked, when none is registered.
4. Distance facts: six checks that decide which clustering methods and which validity measures
   make sense for this data, before any clustering is run.

Three comes before four because the duplicates cause several of the distance numbers.
`distance_concentration.dist_min` and `density_spread.knn4_min` are both 0.000 on phosphatase, and
both are the 163 proteins sitting at zero distance from each other rather than anything about the
geometry. Meeting those zeros before knowing the duplicates exist is how they get misread.

Run it directly to regenerate the outputs:

    python src/data.py [dataset] [--dedup]

- `results/metrics/embedding_profile.json`  the numbers, machine-readable
- `results/embedding_profile.md`       the numbers with what each one means, generated from the
                                       docstrings below so the two cannot drift apart
- `results/metrics/duplicate_groups.csv`    which proteins share a vector with which, one row each

`--dedup` keeps one record per duplicate group and writes to `*_dedup` copies of all three, so the
main run is never overwritten. It is a sensitivity analysis, not a cleaning step: backlog `D4`
records that the supervisors asked for these records to be retained. See `deduplicate` below.

Everything here is deterministic. Conclusions drawn from these numbers belong in
`report/protocol.md`, not here: this file owns the measurement, that file owns the choice.
"""

from __future__ import annotations

import hashlib
import inspect
import io
import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.decomposition import PCA
from sklearn.metrics import pairwise_distances
from sklearn.neighbors import NearestNeighbors

PARQUET_DELIMITER = b"---PARQUET_DELIMITER---"

REPO = Path(__file__).resolve().parents[1]

SEED = 42  # CHOSEN: any value works. Passed to PCA so a run is reproducible on paper.

#: Dataset name to (embeddings, annotation bundle, sequences or None). Adding one is a line here.
#: The name is written into every row of each method's run table, so it is part of the record,
#: not a label.
#:
#: The third entry is a FASTA and it is optional, because `sequence_check` is the only thing that
#: reads it and it reports "not registered" rather than failing when there is none. 3FTx has no
#: FASTA in the repo, so that check simply does not run on it.
#:
#: Phosphatase is primary, nominated by Tobias on 6 August 2026. `data_standard.parquetbundle` is
#: the only clean bundle of the four supplied; see `data/phosphatase/phosphatase/DATA_CARD.md`.
#: 3FTx stays registered as the pilot and regression fixture. `report/protocol.md` §6 names it as
#: the pilot beside phosphatase. It is not evidence for anything.
DATASETS = {
    "phosphatase": (
        REPO / "data/phosphatase/phosphatase/tmp/prot_t5.h5",
        REPO / "data/phosphatase/phosphatase/data_standard.parquetbundle",
        REPO / "data/phosphatase/phosphatase/tmp/sequences.fasta",
    ),
    "three_finger_toxin": (
        REPO / "data/three_finger_toxin/embeddings/three_finger_toxin_prot_t5.h5",
        REPO / "external/protspace/output_curated/data.parquetbundle",
        None,
    ),
}

DEFAULT_DATASET = "phosphatase"


#: Added to every filename on a `--dedup` run so a sensitivity run cannot overwrite the main one.
DEDUP_SUFFIX = "_dedup"


def out_paths(dedup: bool = False) -> tuple[Path, Path, Path]:
    """The three outputs, suffixed on a dedup run. One place, so the trio cannot half-move."""
    s = DEDUP_SUFFIX if dedup else ""
    return (REPO / f"results/metrics/embedding_profile{s}.json",
            REPO / f"results/embedding_profile{s}.md",
            REPO / f"results/metrics/duplicate_groups{s}.csv")


@dataclass
class Dataset:
    """Embeddings and annotations, guaranteed row-aligned."""

    name: str
    ids: list[str]
    X: np.ndarray  # (n, 1024) float32, mean-pooled, unnormalised
    ann: pd.DataFrame  # row i describes ids[i]. 41 columns on the phosphatase bundle

    def __len__(self) -> int:
        return len(self.ids)

    @property
    def subset_hash(self) -> str:
        """Short hash of the sorted IDs actually present.

        The main run keeps every record and sensitivity analyses drop rows, so paired runs differ
        only in `n`. Two runs with the same `n` and different members are otherwise
        indistinguishable in the log.
        """
        # CHOSEN: 12 hex characters. Long enough that two different subsets will not collide
        # at this scale, short enough to read in a CSV.
        return hashlib.sha1("\n".join(sorted(self.ids)).encode()).hexdigest()[:12]


def load_embeddings(path: Path) -> tuple[list[str], np.ndarray]:
    """Read the per-protein mean-pooled ProtT5 vectors."""
    with h5py.File(path, "r") as f:
        ids = list(f.keys())
        X = np.stack([f[k][:] for k in ids])
    return ids, X


def read_fasta(path: Path) -> dict[str, str]:
    """Accession to sequence.

    DERIVED: UniProt writes headers as `>db|accession|entry_name description`, so the accession is
    the second pipe-separated field. A header without pipes falls back to its first token, which is
    what a plain FASTA from another source looks like.
    """
    seqs: dict[str, str] = {}
    key, buf = None, []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line.startswith(">"):
            if key:
                seqs[key] = "".join(buf)
            head = line[1:].split()[0]
            key, buf = (head.split("|")[1] if "|" in head else head), []
        elif line:
            buf.append(line)
    if key:
        seqs[key] = "".join(buf)
    return seqs


def read_bundle_part(path: Path, index: int = 0) -> pd.DataFrame:
    """Read one parquet part out of a .parquetbundle.

    A bundle is concatenated parquet files split on the delimiter and read positionally:
    core(3) + settings? + statistics?. Part 0 is the annotation table.
    """
    parts = path.read_bytes().split(PARQUET_DELIMITER)
    return pd.read_parquet(io.BytesIO(parts[index]))


def load_dataset(name: str = DEFAULT_DATASET) -> Dataset:
    """Load both sides and enforce that IDs match, rather than assuming they do.

    ⚠️ `read_bundle_part(path, 0)` reads the annotation table **positionally**, and alignment alone
    does not prove the bundle is the right one. All four phosphatase bundles aligned identically at
    1,587 rows and three of them carried 30 synthetic test columns. Check the column list at intake.
    """
    if name not in DATASETS:
        raise KeyError(f"unknown dataset '{name}'. Known: {', '.join(DATASETS)}")
    h5_path, bundle_path, _ = DATASETS[name]

    ids, X = load_embeddings(h5_path)
    ann = read_bundle_part(bundle_path, 0)

    missing = set(ids) - set(ann["protein_id"])
    extra = set(ann["protein_id"]) - set(ids)
    if missing or extra:
        raise ValueError(
            f"ID mismatch between embeddings and annotations: "
            f"{len(missing)} only in .h5, {len(extra)} only in the bundle"
        )

    ann = ann.set_index("protein_id").loc[ids].reset_index()
    return Dataset(name=name, ids=ids, X=X, ann=ann)


def lengths(ds: Dataset) -> np.ndarray:
    """Sequence lengths as floats. The bundle stores them as strings."""
    return pd.to_numeric(ds.ann["length"], errors="coerce").to_numpy(dtype=float)


def embedding_qc(ds: Dataset) -> dict:
    """**Scale.** Shape, dtype, and whether the vectors are unit length or raw.

    How: `np.linalg.norm` per row; Pearson correlation of norm against sequence length, and
    against log length as well, in case norm falls off with length rather than tracking it directly.

    Means: `all_unit_norm` false is the fact that makes the Euclidean-versus-cosine choice real,
    because on unit vectors the two rank pairs identically. A strong negative `corr_norm_length`
    would mean the mean pooling leaves length encoded in the magnitude, so a clustering run on raw
    vectors would partly be clustering on protein length.

    Example: phosphatase gives norms 0.961 to 3.930 with `corr_norm_length` = âˆ'0.199. So the
    vectors are not normalised, but length explains almost none of the spread. The tail is instead
    two fragments of 7 and 9 residues, where averaging over very few residues cancels nothing.
    """
    norms = np.linalg.norm(ds.X, axis=1)
    lens = lengths(ds)
    ok = np.isfinite(lens)
    return {
        "n_proteins": len(ds),
        "n_dims": int(ds.X.shape[1]),
        "dtype": str(ds.X.dtype),
        "total_residues": int(np.nansum(lens)),
        "norm_min": round(float(norms.min()), 4),
        "norm_median": round(float(np.median(norms)), 4),
        "norm_max": round(float(norms.max()), 4),
        "norm_sd": round(float(norms.std(ddof=1)), 4),
        "all_unit_norm": bool(np.allclose(norms, 1.0)),
        "corr_norm_length": round(float(np.corrcoef(norms[ok], lens[ok])[0, 1]), 4),
        "corr_norm_log_length": round(float(np.corrcoef(norms[ok], np.log(lens[ok]))[0, 1]), 4),
    }


#: CHOSEN: the usual reporting points. No rule picks them, so the whole curve is drawn in panel 1
#: of `plots.py` and these five are just readable markers on it. `plots.py` imports this rather than
#: repeating a threshold, so the figure cannot mark a point the table does not report.
VAR_THRESHOLDS = (0.5, 0.8, 0.9, 0.95, 0.99)


def effective_dim(X: np.ndarray) -> dict:
    """**How many dimensions actually matter**, against the 1,024 the file says it has.

    How: PCA on the centred matrix, then count components until cumulative explained variance
    crosses each threshold. `participation_ratio` is (Σλ)² / Σλ². It is one number for how many
    directions matter, so you do not have to pick a cut-off.

    Means: this sets the useful PCA range. Reducing to a dimension far above it keeps essentially
    all the variance, so it is slow and changes nothing. It is also the reason to try methods like
    Sub-K-Means, which look for clusters inside a smaller set of directions.

    Example: phosphatase reaches 90% of its variance in 67 components and 99% in 270, with a
    participation ratio of 20.3. So the inherited ladder of PCA-512 and PCA-128 tests almost
    nothing; the informative range is roughly 10 to 120.
    """
    p = PCA(random_state=SEED).fit(X)
    cum = np.cumsum(p.explained_variance_ratio_)
    ev = p.explained_variance_
    out = {f"pc_for_{int(t * 100)}pct": int(np.searchsorted(cum, t)) + 1
           for t in VAR_THRESHOLDS}
    out["pc1_variance_pct"] = round(float(p.explained_variance_ratio_[0] * 100), 2)
    out["participation_ratio"] = round(float(ev.sum() ** 2 / (ev**2).sum()), 2)
    return out


def distance_concentration(flat: np.ndarray) -> dict:
    """**Whether distances stay distinguishable**, or collapse toward one value.

    How: every pairwise Euclidean distance; report (max âˆ' min) / mean, and the coefficient of
    variation std / mean.

    Means: in high dimensions distances tend to concentrate, and the coefficient of variation
    falling toward 0 is the failure. When that happens "nearest" and "furthest" stop differing in
    any useful way, so Euclidean k-means and DBSCAN become meaningless in the raw space and
    everything has to move to a reduced one.

    Example: phosphatase gives a coefficient of variation of 0.223 and relative contrast 3.459.
    That is healthy, so the raw 1,024-dimensional space is usable and reduction is a choice rather
    than a rescue.
    """
    return {
        "dist_min": round(float(flat.min()), 4),
        "dist_mean": round(float(flat.mean()), 4),
        "dist_max": round(float(flat.max()), 4),
        "relative_contrast": round(float((flat.max() - flat.min()) / flat.mean()), 4),
        "coef_variation": round(float(flat.std() / flat.mean()), 4),
    }


def metric_agreement(X: np.ndarray, flat: np.ndarray, iu) -> dict:
    """**Whether Euclidean and cosine rank pairs the same way.**

    How: Spearman rank correlation between the upper triangles of the two distance matrices. Rank
    rather than Pearson, because only the ordering matters to a clustering algorithm.

    Means: near 1.0 the distance choice does not matter and either is fine. Lower means the two
    will produce different partitions, so the choice has to be settled by running both rather than
    by preference. Backlog `S3` owns the decision.

    Example: phosphatase gives 0.8597. Not interchangeable. Tobias recorded a preference for cosine
    on 6 August, and this number says that choice will change the answer.
    """
    C = pairwise_distances(X, metric="cosine")[iu]
    return {"spearman_euclid_cosine": round(float(spearmanr(flat, C).statistic), 4)}


def anisotropy(X: np.ndarray) -> dict:
    """**Whether the vectors crowd into a common direction.**

    How: average cosine similarity over every distinct pair, then repeat after subtracting the
    column mean. Divide both values by `1 / sqrt(d)`, the standard deviation expected between two
    independent random directions in d dimensions, to put spaces of different width on one scale.

    Means: an isotropic space averages near zero. A large positive value means unrelated vectors
    can look similar because they share a dominant direction; mean centring removes that direction
    when the centred value falls near zero. There is no pass/fail threshold in
    `rissom_emmaemb_2026`, so these are measurements, not flags.

    This follows EmmaEmb's `get_anisotropy_diagnostics` with two deliberate differences. EmmaEmb
    samples random pairs with replacement and can pair a point with itself. At this dataset's size
    all unique pairs are cheap enough to use, so this result has neither sampling error nor
    self-pairs. EmmaEmb's second participation-ratio definition is omitted because `effective_dim`
    already reports the PCA-eigenvalue version used by this project.
    """
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2 or X.shape[0] < 2 or X.shape[1] < 1:
        raise ValueError("anisotropy requires a 2-D matrix with at least two rows and one column")
    if not np.isfinite(X).all():
        raise ValueError("anisotropy requires finite embeddings")

    iu = np.triu_indices(len(X), 1)
    expected_random = 1.0 / np.sqrt(X.shape[1])

    avg = float((1.0 - pairwise_distances(X, metric="cosine"))[iu].mean())
    X_centred = X - X.mean(axis=0)
    avg_centred = float(
        (1.0 - pairwise_distances(X_centred, metric="cosine"))[iu].mean()
    )

    return {
        "avg_pairwise_cosine_sim": round(avg, 4),
        "expected_random": round(float(expected_random), 4),
        "anisotropy_score": round(float(avg / expected_random), 4),
        "avg_pairwise_cosine_sim_centred": round(avg_centred, 4),
        "anisotropy_score_centred": round(float(avg_centred / expected_random), 4),
    }


#: CHOSEN: k=4 because DBSCAN's `min_samples` usually sits at 4 or 5 and the two pair up; 10 and 20
#: to show whether the picture changes as the neighbourhood widens. Panel 3 of `plots.py` draws its
#: eps curve at `KNN_KS[0]`, so the figure and the quartiles below describe the same k.
KNN_KS = (4, 10, 20)


def density_spread(X: np.ndarray) -> dict:
    """**Whether one global neighbourhood radius can fit the whole dataset.**

    How: distance to the k-th nearest neighbour for every point at k in {4, 10, 20}; report the
    quartiles and the p75/p25 ratio.

    Means: DBSCAN uses a single `eps` everywhere. If local density varies a lot, no single value
    works: set it for the dense regions and the sparse ones become noise, set it for the sparse
    ones and the dense ones merge. A wide spread is the measured argument for HDBSCAN, which builds
    a hierarchy over densities instead. The quartiles also give the sensible `eps` search range.

    Example: phosphatase has a p75/p25 ratio of 2.8 at k=4, with a median of 0.385 against a
    maximum of 3.93. Density varies about tenfold, so HDBSCAN is preferred on evidence rather than
    on the literature. A `knn4_min` of 0.000 is the 163 proteins with identical embeddings.
    """
    out = {}
    for k in KNN_KS:
        dk = NearestNeighbors(n_neighbors=k + 1).fit(X).kneighbors(X)[0][:, k]
        q25, q75 = np.percentile(dk, [25, 75])
        out[f"knn{k}_min"] = round(float(dk.min()), 4)
        out[f"knn{k}_p25"] = round(float(q25), 4)
        out[f"knn{k}_median"] = round(float(np.median(dk)), 4)
        out[f"knn{k}_p75"] = round(float(q75), 4)
        out[f"knn{k}_max"] = round(float(dk.max()), 4)
        out[f"knn{k}_p75_over_p25"] = round(float(q75 / max(q25, 1e-9)), 2)
    return out


#: QUOTED: the three neighbourhood sizes used for hubness diagnostics by
#: `rissom_emmaemb_2026` Methods p8, following Radovanovic et al. 2010 and Feldbauer et al. 2018.
HUB_KS = (5, 10, 20)


def _knn_without_self(X: np.ndarray, k: int) -> np.ndarray:
    """Return exactly k Euclidean neighbours per row, excluding self by row index.

    Index-based removal matters when rows are identical: self need not be the first zero-distance
    result. The stable full ranking also breaks equal-distance ties by row index. Asking a neighbour
    search for only k+1 candidates leaves the chosen subset of a large duplicate group dependent on
    its tie handling, which made repeated phosphatase runs differ in the fourth decimal of RHI.
    """
    distances = pairwise_distances(X, metric="euclidean")
    np.fill_diagonal(distances, np.inf)
    neighbours = np.argsort(distances, axis=1, kind="stable")[:, :k]

    assert neighbours.shape == (len(X), k)
    assert not np.any(neighbours == np.arange(len(X))[:, None])
    return neighbours


def k_occurrence(neighbours: np.ndarray, k: int) -> np.ndarray:
    """How many times each point appears in another point's k nearest neighbours.

    One line, split out of `hubness` only so panel 7 of `plots.py` can draw the same counts the
    Robin Hood index is computed from. A second implementation there would be free to drift from
    this one, and the figure and the table would stop describing the same thing.
    """
    return np.bincount(neighbours[:, :k].ravel(), minlength=len(neighbours))


def hubness(X: np.ndarray) -> dict:
    """**Whether a few points dominate other points' nearest-neighbour lists.**

    How: at k in {5, 10, 20}, count how often each point occurs among every other point's Euclidean
    k nearest neighbours. The Robin Hood index is the share of all neighbour occurrences that must
    move from above-average points to make the counts uniform. Also report the largest k-occurrence
    and how many points occur in nobody's list.

    Means: the index ranges from 0 for uniform occurrence toward 1 when a few hubs receive nearly
    every occurrence. `rissom_emmaemb_2026` supplies the k values but no severity threshold, so no
    pass/fail flag is invented here. The mean occurrence is exactly k by construction and is
    asserted rather than reported.

    This follows EmmaEmb's `get_hubness_diagnostics`, except self is removed by row index. EmmaEmb
    drops the first zero-distance entry, which can drop another member of a duplicate group while
    retaining self. Index-based removal keeps duplicate proteins as genuine neighbours without
    allowing any point to count itself.
    """
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2 or X.shape[1] < 1:
        raise ValueError("hubness requires a 2-D matrix with at least one column")
    if len(X) <= max(HUB_KS):
        raise ValueError(f"hubness requires more than {max(HUB_KS)} rows")
    if not np.isfinite(X).all():
        raise ValueError("hubness requires finite embeddings")

    out = {}
    neighbours = _knn_without_self(X, max(HUB_KS))
    for k in HUB_KS:
        occurrence = k_occurrence(neighbours, k)
        assert int(occurrence.sum()) == len(X) * k
        assert float(occurrence.mean()) == float(k)

        excess = (occurrence[occurrence > k] - k).sum()
        rhi = float(excess / occurrence.sum())
        out[f"hub{k}_rhi"] = round(rhi, 4)
        out[f"hub{k}_kocc_max"] = int(occurrence.max())
        out[f"hub{k}_kocc_zero"] = int(np.count_nonzero(occurrence == 0))
    return out


#: DERIVED: the stored vectors are float32, good for about 7 decimal digits. Rounding to 6 is one
#: place coarser than that, so identical values stay identical and near-misses from float arithmetic
#: do not split a real duplicate group.
DUP_DECIMALS = 6

#: Annotation columns written beside each duplicated protein, in this order. Chosen to answer the
#: only question the listing exists to answer: are these the same protein from different records, or
#: is something wrong? A column absent from a dataset's bundle is skipped rather than raising, so
#: this works on 3FTx as well.
DUP_CONTEXT = ("uniprot_kb_id", "gene_name", "protein_name", "species", "length", "reviewed",
               "fragment")


def _duplicate_labels(X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Group id for every row, and the size of every group.

    One definition of "duplicate", used by both the count and the listing, so the two cannot report
    different numbers. `.ravel()` because numpy has changed the shape of `return_inverse` under
    `axis=` more than once.
    """
    _, inverse, counts = np.unique(
        X.round(DUP_DECIMALS), axis=0, return_inverse=True, return_counts=True
    )
    return np.asarray(inverse).ravel(), counts


def duplicates(X: np.ndarray) -> dict:
    """**How many proteins share an identical vector with another protein?**

    How: `_duplicate_labels`, which rounds to `DUP_DECIMALS` places and calls `np.unique` on the
    rows. Any row appearing more than once is a duplicate group. The rounding guards against float
    wobble splitting a real match; on phosphatase it changes nothing, the same 56 groups come back
    with no rounding at all.

    Means: these proteins sit at exactly zero distance from each other, and that breaks two things.
    Silhouette measures how close a protein is to its own cluster against the nearest other cluster,
    and the first half of that is zero for a duplicate, so the score is flattered. DBSCAN and HDBSCAN
    read a pile of points at zero distance as the densest possible region, so a "cluster" can be
    nothing more than the same protein sequenced several times.

    They are not automatically an error. Two strains of the same bacterium genuinely have the same
    protein. Whether to keep them, collapse each group to one representative, or report them
    separately is a protocol decision, and `report/protocol.md` §3 owns it. This function only
    counts them. `duplicate_groups` says which they are.

    Example: phosphatase has 56 groups covering 163 proteins, 10.3% of the set. The largest is 10
    strains of *Staphylococcus aureus* PtpB. They come from 56 identical amino-acid sequences, and
    ProtT5 is deterministic, so the same sequence gives byte-for-byte the same vector.
    """
    _, counts = _duplicate_labels(X)
    dup = counts[counts > 1]
    return {
        "n_unique_vectors": int(len(counts)),
        "n_duplicate_groups": int(len(dup)),
        "n_proteins_in_groups": int(dup.sum()),
        "pct_proteins_in_groups": round(float(dup.sum() / len(X) * 100), 2),
        "largest_group": int(dup.max()) if len(dup) else 0,
    }


def duplicate_groups(ds: Dataset) -> pd.DataFrame:
    """**Which proteins share a vector**, one row per protein, ready to read.

    How: group the rows exactly as `duplicates` above counts them, keep only the groups with more
    than one member, and attach the annotation columns in `DUP_CONTEXT`. Groups are numbered from 1,
    largest first, and rows are ordered by group then by `protein_id`.

    Means: `duplicates` gives the totals, this gives the members. Four extra columns do the actual
    work. `n_species` and `n_lengths` count the distinct values inside each group, so a group of ten
    records of one protein from one organism reads differently from a group whose members disagree
    about their own sequence length. ProtT5 is deterministic, so identical vectors should mean
    identical sequences; a group with more than one length is a reason to go back to the FASTA.

    `dims_equal_in_group` and `vector_sha1` are the evidence, so the grouping does not have to be
    taken on trust. The first counts, for the worst member of each group, how many of the stored
    values match the group's first member. Anything below the full width means the group was built
    on rounded agreement rather than real agreement. The second hashes the raw bytes of the stored
    vector, so two rows carry the same hash only if their vectors are byte for byte the same.

    Example: on phosphatase every group reports 1024 of 1024, and two proteins from different groups
    share 0 of 1024 values, so the test is neither passing on rounding nor passing trivially.

    Written to `results/metrics/duplicate_groups.csv`. Deciding what to do with them is
    `report/protocol.md` §3, not this file.
    """
    Xf = np.asarray(ds.X)
    labels, counts = _duplicate_labels(np.asarray(Xf, dtype=np.float64))
    keep = counts[labels] > 1
    kept = np.flatnonzero(keep)

    cols = [c for c in DUP_CONTEXT if c in ds.ann.columns]
    out = ds.ann.loc[keep, ["protein_id", *cols]].copy()
    out.insert(0, "_label", labels[keep])
    out.insert(0, "group_size", counts[labels][keep])
    out["vector_sha1"] = [hashlib.sha1(Xf[i].tobytes()).hexdigest()[:12] for i in kept]

    agree = {}
    for lab in np.unique(labels[keep]):
        rows = Xf[np.flatnonzero(labels == lab)]
        agree[lab] = int((rows == rows[0]).sum(axis=1).min())
    out["dims_equal_in_group"] = out["_label"].map(agree)

    # Number the groups largest first so the interesting ones are at the top of the file.
    order = (out.groupby("_label")["group_size"].first()
                .sort_values(ascending=False, kind="stable").index)
    out["group_id"] = out["_label"].map({lab: i for i, lab in enumerate(order, start=1)})

    for col, name in (("species", "n_species"), ("length", "n_lengths")):
        if col in out.columns:
            out[name] = out.groupby("_label")[col].transform("nunique")

    out = out.drop(columns="_label").sort_values(["group_id", "protein_id"], kind="stable")
    front = ["group_id", "group_size", "dims_equal_in_group", "vector_sha1",
             *[c for c in ("n_species", "n_lengths") if c in out.columns]]
    return out[[*front, *[c for c in out.columns if c not in front]]].reset_index(drop=True)


def deduplicate(ds: Dataset) -> Dataset:
    """Keep one record per duplicate group and drop the rest. Never the default.

    CHOSEN: the survivor is the member whose `protein_id` sorts first. Arbitrary, and deliberately
    so. The vectors inside a group are identical, so no choice among them changes the geometry by
    one decimal place, and any rule that consulted the annotations would smuggle a preference into a
    step meant to be neutral. Sorting is at least deterministic and needs no defending.

    ⚠️ Arbitrary is not the same as free. What a group loses is annotation rows, not geometry. On
    phosphatase 26 of the 56 groups span more than one species, so keeping one member of the PPP1CB
    group discards eight species labels for a protein that is identical across nine vertebrates.
    Backlog `D4` asks whether species explains cluster structure, and this step deletes some of the
    evidence that test would need.

    Row order and the annotation table's alignment are preserved: survivors come back in the order
    the `.h5` gave them, not in sorted order.

    `report/protocol.md` §3 owns whether to do this at all. This function only carries it out when
    `--dedup` asks.
    """
    labels, _ = _duplicate_labels(np.asarray(ds.X, dtype=np.float64))
    keep = np.zeros(len(ds), dtype=bool)
    seen: set[int] = set()
    for i in np.argsort(np.asarray(ds.ids), kind="stable"):
        lab = int(labels[i])
        if lab not in seen:
            seen.add(lab)
            keep[i] = True
    idx = np.flatnonzero(keep)
    return Dataset(name=ds.name, ids=[ds.ids[i] for i in idx], X=ds.X[idx],
                   ann=ds.ann.iloc[idx].reset_index(drop=True))


#: Reported by `sequence_check` whatever happens, so the profile has the same shape on every
#: dataset and a missing FASTA reads as "not checked" rather than as a silently absent section.
_SEQ_KEYS = ("n_sequences_in_fasta", "ids_missing_from_fasta", "duplicate_groups_checked",
             "groups_with_one_sequence", "groups_with_more_than_one_sequence",
             "distinct_sequences_across_groups", "fasta_length_matches_annotation")


def sequence_check(ds: Dataset) -> dict:
    """**Did identical vectors come from identical sequences**, or did mean pooling flatten them?

    How: read the FASTA registered for this dataset, take the duplicate groups exactly as
    `duplicates` defines them, and count the distinct sequences inside each one. Also compare each
    sequence's length against the `length` column of the annotation table.

    Means: `duplicates` proves that two rows of the `.h5` are the same. It cannot say why. Two
    different proteins landing on one vector because averaging over residues threw away what
    separated them would be a fact about mean pooling, and it would put every duplicate-derived
    conclusion in doubt. Identical sequences instead mean the model was handed the same input twice
    and, being deterministic, returned the same answer. The two readings call for opposite responses,
    so this settles which one applies before `report/protocol.md` §3 decides anything.

    `groups_with_more_than_one_sequence` is the number that matters. Zero is the clean result.
    Anything above zero is a pooling collapse and wants investigating before the duplicates are
    treated as records of one protein.

    Example: phosphatase has 1,587 sequences in its FASTA, none of the 163 grouped proteins missing,
    all 56 groups down to one sequence each, 56 distinct sequences across the 56 groups, and every
    FASTA length matching the annotation. So the duplicates are the same protein sequenced more than
    once, not a pooling artefact.

    A dataset with no FASTA registered in `DATASETS` reports `fasta_registered` false and nothing
    else, which is the honest answer rather than a skipped section. 3FTx is that case today.
    """
    fasta = DATASETS.get(ds.name, (None, None, None))[2]
    if fasta is None or not Path(fasta).exists():
        return {"fasta_registered": False, **{k: None for k in _SEQ_KEYS}}

    seqs = read_fasta(Path(fasta))
    labels, counts = _duplicate_labels(np.asarray(ds.X, dtype=np.float64))
    ann_len = pd.to_numeric(ds.ann["length"], errors="coerce").to_numpy(dtype=float)

    one, many, firsts, missing, len_ok = 0, 0, [], 0, True
    for lab in np.unique(labels[counts[labels] > 1]):
        members = np.flatnonzero(labels == lab)
        found = [ds.ids[i] for i in members if ds.ids[i] in seqs]
        missing += len(members) - len(found)
        if not found:
            continue
        distinct = {seqs[p] for p in found}
        one, many = one + (len(distinct) == 1), many + (len(distinct) > 1)
        firsts.append(seqs[found[0]])
        for i in members:
            if ds.ids[i] in seqs and np.isfinite(ann_len[i]):
                len_ok &= len(seqs[ds.ids[i]]) == int(ann_len[i])

    return {
        "fasta_registered": True,
        "n_sequences_in_fasta": len(seqs),
        "ids_missing_from_fasta": int(missing),
        "duplicate_groups_checked": one + many,
        "groups_with_one_sequence": int(one),
        "groups_with_more_than_one_sequence": int(many),
        "distinct_sequences_across_groups": len(set(firsts)),
        "fasta_length_matches_annotation": bool(len_ok),
    }


def embedding_profile(ds: Dataset) -> dict[str, dict]:
    """Every check, grouped by the function that produced it."""
    X = np.asarray(ds.X, dtype=np.float64)
    D = pairwise_distances(X)
    iu = np.triu_indices(len(X), 1)
    flat = D[iu]
    return {
        "embedding_qc": embedding_qc(ds),
        "duplicates": duplicates(X),
        "sequence_check": sequence_check(ds),
        "effective_dim": effective_dim(X),
        "distance_concentration": distance_concentration(flat),
        "metric_agreement": metric_agreement(X, flat, iu),
        "anisotropy": anisotropy(X),
        "density_spread": density_spread(X),
        "hubness": hubness(X),
    }


_FUNCS = {"embedding_qc": embedding_qc, "duplicates": duplicates,
          "sequence_check": sequence_check, "effective_dim": effective_dim,
          "distance_concentration": distance_concentration, "metric_agreement": metric_agreement,
          "anisotropy": anisotropy, "density_spread": density_spread, "hubness": hubness}


def write_profile_md(name: str, groups: dict[str, dict], path: Path,
                     *, dedup: bool = False) -> None:
    """Numbers plus their explanation, generated from the docstrings so the two cannot drift."""
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    which = " — deduplicated, one record per duplicate group" if dedup else ""
    cmd = f"src/data.py{' --dedup' if dedup else ''}"
    out = [f"# Embedding profile — {name}{which}", "",
           f"Generated by `{cmd}` on {stamp}. Seed {SEED}. Do not edit by hand.",
           "", "Conclusions drawn from these numbers belong in `report/protocol.md`.", ""]
    for group, values in groups.items():
        # `cleandoc`, not `strip`. A docstring's first line starts at the quote and every line
        # after it is indented to match the `def`, and `strip` only reaches the first one. Four
        # spaces after a blank line is an indented code block in Markdown, so every explanation
        # below rendered as monospace with its backticks and bold showing as literal characters.
        out += [f"## {group}", "", inspect.cleandoc(_FUNCS[group].__doc__ or ""), "",
                "| metric | value |", "|---|---|"]
        out += [f"| `{k}` | {v} |" for k, v in values.items()]
        out.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(out), encoding="utf-8")


def main() -> None:
    argv = sys.argv[1:]
    dedup = "--dedup" in argv
    unknown = [a for a in argv if a.startswith("-") and a != "--dedup"]
    if unknown:
        raise SystemExit(f"unknown flag '{unknown[0]}'. Usage: python src/data.py [dataset] [--dedup]")
    names = [a for a in argv if not a.startswith("-")]
    name = names[0] if names else DEFAULT_DATASET

    ds = load_dataset(name)
    n_loaded = len(ds)
    if dedup:
        ds = deduplicate(ds)
    groups = embedding_profile(ds)
    json_path, md_path, csv_path = out_paths(dedup)

    flat = {f"{g}.{k}": v for g, vals in groups.items() for k, v in vals.items()}
    header = {"dataset": name, "seed": SEED, "dedup": dedup, "n": len(ds),
              "subset_hash": ds.subset_hash}
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps({**header, **flat}, indent=2) + "\n")
    write_profile_md(name, groups, md_path, dedup=dedup)

    dups = duplicate_groups(ds)
    dups.to_csv(csv_path, index=False)

    for group, values in groups.items():
        print(f"\n### {group}")
        for k, v in values.items():
            print(f"  {k:<26} {v}")
    if dedup:
        print(f"\ndedup: {n_loaded} records in, {len(ds)} out, {n_loaded - len(ds)} dropped")
    print(f"{len(dups)} proteins in {dups['group_id'].nunique() if len(dups) else 0} duplicate "
          f"groups -> {csv_path.relative_to(REPO)}")
    print(f"written to {json_path.relative_to(REPO)} and {md_path.relative_to(REPO)}")


if __name__ == "__main__":
    main()
