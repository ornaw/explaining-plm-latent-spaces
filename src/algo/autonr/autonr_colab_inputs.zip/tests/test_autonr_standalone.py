"""AutoNR boundaries plus a real-library differential and disk round-trip check.

The small synthetic fixture tests implementation, not protein performance. Its
seed and size are CHOSEN to exercise the native search without a scientific grid.
"""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from sklearn.datasets import make_blobs
from sklearn.metrics import adjusted_rand_score

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('autonr', ROOT / 'src/algo/autonr/autonr_standalone.py')
an = importlib.util.module_from_spec(spec)
spec.loader.exec_module(an)


class AutoNRTests(unittest.TestCase):
    def fixture(self):
        return dict(protein_id=np.array(['a', 'b', 'c', 'd']),
                    label=np.array([[0, -1], [0, 0], [1, 0], [-1, 0]]),
                    V=np.eye(3), m=np.array([1, 2]), n_clusters=np.array([2, 1]),
                    P_0=np.array([0]), P_1=np.array([1, 2]),
                    centres_0=np.zeros((2, 3)), centres_1=np.zeros((1, 3)),
                    scatter_0=np.eye(3), scatter_1=np.eye(3))

    def test_canonical_alignment(self):
        ids, X = an.canonical_input(['b', 'a'], [[2, 3], [0, 1]])
        np.testing.assert_array_equal(ids, ['a', 'b'])
        np.testing.assert_array_equal(X, [[0, 1], [2, 3]])
        for ids, X in [(['a', 'a'], np.ones((2, 2))),
                       (['a', 'b'], [[0, 1], [np.nan, 2]]),
                       (['a', 'b'], np.ones((3, 2)))]:
            with self.assertRaises(ValueError):
                an.canonical_input(ids, X)

    def test_multiple_spaces_and_independent_outliers(self):
        an.validate_arrays(self.fixture(), 4, 3)

    def test_malformed_saved_arrays(self):
        changes = [('label', np.zeros(4, dtype=int)), ('P_1', np.array([0, 1])),
                   ('m', np.array([1, 1])), ('centres_0', np.zeros((2, 1))),
                   ('label', np.array([[0, -2], [0, 0], [1, 0], [-1, 0]])),
                   ('protein_id', np.array(['b', 'a', 'c', 'd'])),
                   ('V', np.ones((3, 3)))]
        for key, value in changes:
            with self.subTest(key=key):
                a = self.fixture()
                a[key] = value
                with self.assertRaises((ValueError, AssertionError)):
                    an.validate_arrays(a, 4, 3)

    def test_source_mismatch(self):
        with patch.object(an, 'SOURCES', {'alternative/autonr.py': 'wrong'}):
            with self.assertRaisesRegex(ValueError, 'source mismatch'):
                an.verify_source()

    def test_native_coding_with_duplicates_and_constant_feature(self):
        # Independent sorted-difference route verifies the library's pairwise
        # precision calculation on repeated values and one constant feature.
        X = np.array([[0., 5., 0.], [0., 5., 0.], [2., 5., 3.], [6., 5., 9.]])
        values = an.coding_quantities(X)
        minima = [np.diff(np.unique(col)).min() for col in X.T if len(np.unique(col)) > 1]
        self.assertEqual(values['precision'], np.mean(minima))
        self.assertEqual(values['max_distance'], np.linalg.norm(X[0] - X[-1]))
        with self.assertWarns(RuntimeWarning), self.assertRaises(ValueError):
            an.coding_quantities(np.ones((4, 3)))

    def test_write_once_and_no_fit_on_collision(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            an.write_json(path / 'x.json', {'a': 1})
            with self.assertRaises(FileExistsError):
                an.write_json(path / 'x.json', {'a': 2})
            with patch.object(an, 'prepare') as prepare:
                with self.assertRaises(FileExistsError):
                    an.run(path, 'full', 0)
                prepare.assert_not_called()

    def test_cancel_owned_process(self):
        child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])
        try:
            an.stop_tree(child.pid)
            child.wait(timeout=10)
            self.assertIsNotNone(child.returncode)
        finally:
            if child.poll() is None:
                child.kill()

    def test_real_library_and_disk_roundtrip(self):
        X, _ = make_blobs(n_samples=45, centers=3, n_features=2,
                          cluster_std=0.4, random_state=7)
        ids, X = an.canonical_input([f'p{i:03}' for i in range(len(X))], X)
        with contextlib.redirect_stdout(io.StringIO()):
            a, info = an.fit_arrays(ids, X, 0)
            # Native defaults independently specified, not the wrapper's factory.
            direct = an.verify_source()(random_state=0).fit(X)
        np.testing.assert_array_equal(a['n_clusters'], direct.n_clusters_)
        for j in range(a['label'].shape[1]):
            self.assertEqual(adjusted_rand_score(a['label'][:, j], direct.labels_[:, j]), 1.)
        self.assertAlmostEqual(info['mdl'], direct.mdl_costs_)
        self.assertIn('unknown', info['inner_termination'])
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            config = dict(input=an.input_signature(ids, X), records='full')
            an.write_json(path / 'configuration.json', config)
            np.savez_compressed(path / 'model.npz', **a)
            info.update(archive_sha256=an.digest(path / 'model.npz'),
                        configuration_id=an.digest(path / 'configuration.json'))
            an.save_tables(path, a, info, info['configuration_id'])
            info['table_hashes'] = {p.name: an.digest(p) for p in path.glob('*.csv')}
            an.write_json(path / 'result.json', info)
            with patch.object(an, 'prepare', return_value=(ids, X, 'float64')):
                reopened, _ = an.validate_saved(path, require_success=False)
                for key in a:
                    np.testing.assert_array_equal(a[key], reopened[key])
                with self.assertRaises(FileNotFoundError):
                    an.validate_saved(path)
                an.write_json(path / 'SUCCESS.json', dict(result_sha256=an.digest(path / 'result.json')))
                an.validate_saved(path)
                with (path / 'model.npz').open('ab') as stream:
                    stream.write(b'corruption')
                with self.assertRaisesRegex(ValueError, 'archive hash'):
                    an.validate_saved(path)


if __name__ == '__main__':
    unittest.main()
